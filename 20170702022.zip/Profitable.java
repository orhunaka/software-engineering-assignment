interface Profitable {
    
    public double calculate();
}
